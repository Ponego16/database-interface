﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
          Author model = new Author();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            clear();

        }
        void clear()
        {
            txtAuthorID.Text = txtFirstName.Text = txtLastName.Text = txtAge.Text = txtBookID.Text = "";
            btnSave.Text = "Save";
            btnDelete.Enabled = false;
            model.AuthorID = 11;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clear();
            this.ActiveControl = txtAuthorID;
            LoadData();
        }

        private void btnSave_Click(object sender, EventArgs e)
    
        {
            model.AuthorID =int.Parse(txtAuthorID.Text.Trim());
            model.FirstName = txtFirstName.Text.Trim();
            model.LastName = txtLastName.Text.Trim();
            model.Age = int.Parse(txtAge.Text.Trim());
            model.BookID = int.Parse(txtBookID.Text.Trim());
            using( Library_DatabaseEntities db = new Library_DatabaseEntities())
            {
                if(model.AuthorID == 0) //insert
               
                db.Authors.Add(model);
                else
                  db.Entry(model).State = EntityState.Modified;
                db.SaveChanges();   

            }
            clear();
            LoadData();
            MessageBox.Show("Saved Succesfully");
       
        
        }
        void LoadData()
        {
            using(Library_DatabaseEntities db = new Library_DatabaseEntities())
            {
                dgvAuthor.DataSource = db.Authors.ToList<Author>();
            }
        }

        private void dgvAuthor_DoubleClick(object sender, EventArgs e)
        {
            if(dgvAuthor.CurrentRow.Index != -1) 
            {
                model.AuthorID = Convert.ToInt32(dgvAuthor.CurrentRow.Cells["dgAuthorID"].Value);
                using(Library_DatabaseEntities db =new Library_DatabaseEntities())
                { 
                    model = db.Authors.Where(x => x.AuthorID == model.AuthorID).FirstOrDefault();
                    txtAuthorID.Text = model.AuthorID.ToString();
                    txtFirstName.Text = model.FirstName;
                    txtLastName.Text = model.LastName;
                    txtAge.Text = model.Age.ToString();
                    txtBookID.Text = model.BookID.ToString();
                }
                btnSave.Text = "Update";
                btnDelete.Enabled = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this record","Message",MessageBoxButtons.YesNo) == DialogResult.Yes)

            {
              using(Library_DatabaseEntities db=new Library_DatabaseEntities())
                {
                    var entry = db.Entry(model);
                    if(entry.State == EntityState.Detached)
                    {
                        db.Authors.Attach(model);
                        db.Authors.Remove(model);
                        db.SaveChanges();
                        LoadData();
                        clear();
                        MessageBox.Show("Deleted Successfully");
                    }
                }
            }
        }
    }
}
